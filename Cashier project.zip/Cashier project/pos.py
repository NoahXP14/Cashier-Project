import random
import math



def price():
    a = (float(input("how much does it cost? $")))
    return a

items = (int(input("how many items? ")))

subtotal = 0


for receipt in range(items):
    name = input("Item: ")
    next = price()
    print()
    print()
    print()
    print()
    print()
    print()
    print()
    print()
    print()
    print()
    print()
    print(name, "cost", next)
    subtotal =  items * next 
    gst = subtotal * 0.05
    print("________________________")
    print("subtotal is", subtotal,"$")
    print("tax is ", gst,"$")
    print("total is ", subtotal + gst,"$")

    


